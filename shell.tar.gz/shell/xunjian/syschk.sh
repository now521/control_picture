#!/bin/sh
#定义检查操作系统版本的函数
#MEM_F=$(${DB_COM} -h${DB_H} -u${DB_USER} -p${DB_PASS} threshold -e "select id from thresholdvalue where code='mem';"|awk 'NR>1')
VERNO=$(uname -r|cut -c 14)  #系统版本号
CONF_DIR=`dirname $0`/config #脚本配置文件目录
LOG_DIR=`dirname $0`/log     #脚本日志文件目录
HN=`hostname`                #当前服务器机器名
date=`date +"%Y%m%d"`        #日期
date1=`date +"%Y%m%d%H%M%S"` #日期
date2=`date +"%Y-%m-%d %H:%M:%S"`  #日期
date3=`date -d '-1 day' +"%Y-%m-%d %H:%M:%S"` #日期
dateold=`date -d '-1 day' +%Y%m%d` #日期
netcard=$(awk 'NR==1{print}' ${CONF_DIR}/sys.ini) #获取当前服务器的网卡名称
IP=`ifconfig ${netcard}|grep inet" "|awk -F" " '{print $2}'|awk -F: '{print $2}'` #获取当前服务器的ip
#需要调试的变量
NIFI_PORT=8085              #nifi服务的端口
MFSCGISERV_PORT=9425        #mfscgiserv的端口
quality_port=8080           #质检服务的端口
quality_tomcat_dir=/root/tomcat7/     #质检tomcat服务的端口
quality_wildfly_dir=/root/wildfly-10.1.0.Final    #质检wildfly服务的端口
cesic_T_dir=/root/cesic/tomcat7       #归集tomcat服务的端口
cesic_W_dir=/root/wildfly10-cesic     #归集wildfly服务的端口
redis_port=6379                       #redis服务的端口
redis_cli=/usr/local/redis/bin/redis-cli          #redis服务执行文件的绝对路径
solr_dir=/opt/solr-5.5.1    #solr服务所在的绝对路径
solr_port=8983              #solr服务的端口
smartv_port=8081            #运维监控服务的端口
SOLR_SH=/ccicall/opt/solr-5.5.1/bin/solr          #solr执行文件的绝对路径
SOLR_IP=${IP}               #solr服务的IP地址
SOLR_PORT=9983              #solr服务的端口
#CDH_V5_IP=10.0.3.45
CDH_V_IP=10.0.4.11         #cdh服务nn节点的ip
CDH_PORT=7180              #nn节点的cdh服务的端口
V=v5/clusters/Cluster%201%20-%20CDH4              #cdh服务相应版本对应的接口链接
#V=v11/clusters/Cluster%201
USER=admin                 #cdh服务的用户名 
PASS=admin                 #cdh服务的密码
downloads=/mnt/mfs/ftp_downloads/${dateold}       #原始语音文件存放的目录（检测语音转译情况需要的配置）
results=/mnt/mfs/voice_recognize_results${date}*  #转译文本存放的目录（检测语音转译情况需要的配置）

#数据库信息
DB_COM=/usr/bin/mysql
#DB_COM=/ccicall/opt/mysql-5.7.16-linux-glibc2.5-x86_64/bin/mysql #mysql服务命令所在的绝对路径
DB_H=172.30.4.2             #mysql服务器ip
DB_PORT=3306               #mysql服务的端口
DB=manager                 #mysql所用的库名
DB_USER=root               #mysql服务的用户名
DB_PASS=root123            #mysql服务的密码
DB_L=service_list          #mysql的服务器列表所在的表
DB_S=service_exception     #mysql的服务器异常所在的表
DB_P=process_exception     #mysql的应用异常所在的表
DB_Y=threshold             #mysql的阈值所在的表
DB_LI=log_info             #mysql的日志信息所在的表
DB_LT=log_task             #mysql的日志设置所在的表
DB_LE=log_exception        #mysql的日志信息所在的表
DB_LL=log_list             #mysql的日志信息所在的表
DB_LLF=log_list_file       #mysql的日志信息所在的表
#数据库check_info的对应ID
PING_CI=1       #ping
FIREWALL_CI=2    #防火墙
CPU_CI=3         #cpu
MEM_CI=4         #内存
DISK_CI=5        #磁盘
DISKIO_CI=6      #磁盘IO
NET_IO_CI=7      #网络流量

MYSQL_CI=1       #数据库MySQL
NIFI_CI=2        #nifi服务
MFSM_CI=3        #mfsmaster服务
MFSL_CI=4        #mfsmetalogger服务
MFSG_CI=5        #mfscgiserv服务
MFSC_CI=6        #mfschunkserver服务
MFST_CI=7        #mfsclient服务
ENGINE_CI=8      #引擎
QUALITY_CI=9     #质检服务
CESIC_CI=10      #归集服务
REDIS_CI=11      #redis服务
CDH_NN_CI=12     #nn节点上的cdh服务
CDH_DN_CI=13     #dn节点上的cdh服务
SOLR_CI=14       #solr服务
SMARTV_CI=15     #运维平台服务
SOLR_IF_CI=16    #solr接口
CDH_IF_CI=17     #cdh接口
REDIO_CI=18      #转译文本情况
HBASE_CI=19      #hbase服务
HDFS_CI=20       #hdfs服务
HIVE_CI=21       #hive服务
FTP_CI=22       #ftp服务
DB_L_FIELD=hostname,ip,cpu,mem,disk,os,line_time,remark,report_time
DB_S_FIELD=check_info,status,remark,report_time,service_id
DB_P_FIELD=process_name,status,remark,report_time,service_id
DB_LE_FIELD=check_info,log_name,log_time,log_line,status,report_time,service_id
DB_LL_FIELD=list,log_name,warn_info,status,add_time,service_id,log_line,err_line
DB_LLF_FIELD=list,log_name,warn_info,status,add_time,service_id,log_line,err_line
DB_LT_FIELD=list,log_name,warn_info,status,add_time,service_id,log_line
DB_P_FIELD=process_name,status,remark,report_time,service_id
######服务器列表信息######"
sys_list () {
CPUNO=`cat /proc/cpuinfo| grep "processor"| wc -l`
CPUX=$(cat /proc/cpuinfo | grep name | cut -f2 -d: | uniq -c|awk '{for(i=2;i<NF;i++)printf $i" ";print $i}')
MEMTOTAL=`free -m|grep Mem|awk -F" " '{print $2}'`
OS_VERSION=$(cat /etc/redhat-release)
LINETIME=$(uptime | awk -F"up" '{print $2}' | awk -F",  load average" '{print $1}')
DISK_T=$(df -k | grep -v "tmpfs" | awk 'NR>1&&NF>1{print $(NF-4)}' | awk -v total=0 '{total+=$1}END{printf "%.2f\n",total/1048576}')
DISK_F=$(df -k|sed 1d|awk '{print $1":"$2/1048576}'|awk '{printf("%s",$0"G<br/>")}')
LIST_C=$(${DB_COM} -h${DB_H} -u${DB_USER} -p${DB_PASS} ${DB} -e "select count(*) from ${DB_L} where ip='${IP}';"|awk 'NR>1')
if [[ ${LIST_C} -eq 0 ]] ; then
${DB_COM} -h${DB_H} -u${DB_USER} -p${DB_PASS} ${DB} -e "insert into ${DB_L} (${DB_L_FIELD}) values ('${HN}','${IP}','核数：${CPUNO}<br/>型号：${CPUX}','${MEMTOTAL}"M"','总大小：${DISK_T}G<br/>分别为：${DISK_F}','${OS_VERSION}','${LINETIME}','',NOW());"
else
${DB_COM} -h${DB_H} -u${DB_USER} -p${DB_PASS} ${DB} -e "update ${DB_L} set cpu='核数：${CPUNO}<br/>型号：${CPUX}',mem='${MEMTOTAL}"M"',disk='总大小：${DISK_T}G<br/>分别为：${DISK_F}',os='${OS_VERSION}',line_time='${LINETIME}',report_time=NOW() where ip='${IP}';" #服务器列表信息更新
fi
echo "${date2} ${HN},${IP},核数：${CPUNO}；型号：${CPUX},${MEMTOTAL}M,总大小：${DISK_T}G<br\>分别为：${DISK_F},${OS_VERSION},${LINETIME}">>${LOG_DIR}/log.log
}
KEY_ID=$(${DB_COM} -h${DB_H} -u${DB_USER} -p${DB_PASS} ${DB} -e "select id from service_list where ip='${IP}' limit 1"|awk 'NR>1')
######客户端能否ping通######"
PING () {
CLIENT_IP=$(${DB_COM} -h${DB_H} -u${DB_USER} -p${DB_PASS} ${DB} -e "select ip from ${DB_L}" |awk 'NR>1')
for hostip in `echo -e "${CLIENT_IP}"|sed '/${IP}/d'`
do
PING_ID=$(${DB_COM} -h${DB_H} -u${DB_USER} -p${DB_PASS} ${DB} -e "select id from service_list where ip='${hostip}' limit 1"|awk 'NR>1')
      ping -c 1 -W 2 $hostip &> /dev/null
        if [[ "$?" != "0" ]];then
#         if [ ${?} -ne 2 ] ;then
PING_C=$(${DB_COM} -h${DB_H} -u${DB_USER} -p${DB_PASS} ${DB} -e "select count(*) from  ${DB_S} where service_id='${PING_ID}' and check_info='${PING_CI}';"|awk 'NR>1')
echo "${date2} $hostip is DOWN">>${LOG_DIR}/log.log
           if [[ ${PING_C} -eq 0 ]] ; then
                   echo $hostip is DOWN
${DB_COM} -h${DB_H} -u${DB_USER} -p${DB_PASS} ${DB} -e "insert into ${DB_S} (${DB_S_FIELD}) values ('${PING_CI}','1','$hostip is DOWN',NOW(),'${PING_ID}');"
           else
${DB_COM} -h${DB_H} -u${DB_USER} -p${DB_PASS} ${DB} -e "update ${DB_S} set status='1',remark='${hostip} is DOWN',report_time=NOW() where check_info='${PING_CI}' and service_id='${PING_ID}';"
           fi
        else
${DB_COM} -h${DB_H} -u${DB_USER} -p${DB_PASS} ${DB} -e "delete from ${DB_S} where check_info='${PING_CI}' and service_id='${PING_ID}';"
        fi
done
}
######防火墙是否开启######"
firewall () {
#PING_ID=$(${DB_COM} -h${DB_H} -u${DB_USER} -p${DB_PASS} ${DB} -e "select id from  ${DB_L} where ip='${hostip}' limit 1;"|awk 'NR>1')
FIRE_C=$(${DB_COM} -h${DB_H} -u${DB_USER} -p${DB_PASS} ${DB} -e "select count(*) from  ${DB_S} where service_id='${KEY_ID}' and check_info='${FIREWALL_CI}';"|awk 'NR>1')
if [[ ${VERNO} -eq 6 ]] ; then
  /etc/init.d/iptables status 1>/dev/null 2>&1
  RESULT6_IPTABLES=$?
  if [[ ${RESULT6_IPTABLES} -ne 0 ]]
   then
echo "${date2} 防火墙已开启">>${LOG_DIR}/log.log
      if [[ ${FIRE_C} -eq 0 ]] ; then
${DB_COM} -h${DB_H} -u${DB_USER} -p${DB_PASS} ${DB} -e "insert into ${DB_S} (${DB_S_FIELD}) values ('${FIREWALL_CI}','1','防火墙已开启',NOW(),'${KEY_ID}');"
      else
${DB_COM} -h${DB_H} -u${DB_USER} -p${DB_PASS} ${DB} -e "update ${DB_S} set status='1',remark='防火墙已开启',report_time=NOW() where check_info='${FIREWALL_CI}' and service_id='${KEY_ID}';"
      fi
  else
${DB_COM} -h${DB_H} -u${DB_USER} -p${DB_PASS} ${DB} -e "delete from ${DB_S} where check_info='${FIREWALL_CI}' and service_id='${KEY_ID}';"
  fi
elif [[ ${VERNO} -eq 7 ]] ; then
  systemctl status firewalld.service 1>/dev/null 2>&1
  RESULT7_IPTABLES=$?
  if [[ ${RESULT7_IPTABLES} -ne 0 ]]
   then
echo "${date2} 防火墙已开启">>${LOG_DIR}/log.log
      if [[ ${FIRE_C} -eq 0 ]] ; then
${DB_COM} -h${DB_H} -u${DB_USER} -p${DB_PASS} ${DB} -e "insert into ${DB_S} (${DB_S_FIELD}) values ('${FIREWALL_CI}','1','防火墙已开启',NOW(),'${KEY_ID}');"
      else
${DB_COM} -h${DB_H} -u${DB_USER} -p${DB_PASS} ${DB} -e "update ${DB_S} set status='1',remark='防火墙已开启',report_time=NOW() where check_info='${FIREWALL_CI}' and service_id='${KEY_ID}';"
      fi
  else
${DB_COM} -h${DB_H} -u${DB_USER} -p${DB_PASS} ${DB} -e "delete from ${DB_S} where check_info='${FIREWALL_CI}' and service_id='${KEY_ID}';"
  fi

fi

}
######CPU使用情况######"
sys () {
CPU_LOAD_USE=$(top -bn 1 | grep "Cpu(s)"|awk -F" " '{print $3}'|awk -F"%" '{print $1"%"}')
CPU_LOAD_USE1=$(top -bn 1 | grep "Cpu(s)"|awk -F" " '{print $3}'|awk -F"%" '{print $1"%"}'|awk -F. '{print $1}')
CPU_LOAD_FREE=$(top -bn 1 | grep "Cpu(s)"|awk -F" " '{print $5}'|awk -F"%" '{print $1"%"}')
#CPU_ID=$(${DB_COM} -h${DB_H} -u${DB_USER} -p${DB_PASS} ${DB} -e "select service_id from  ${DB_S} where check_info='${PING_CI}' and service_id=${KEY_ID} limit 1"|awk 'NR>1')1
CPU_Y=$(${DB_COM} -h${DB_H} -u${DB_USER} -p${DB_PASS} ${DB} -e "select threshold_value from ${DB_Y} where status='0' and check_info='${CPU_CI}' limit 1;"|awk 'NR>1')
CPU_C=$(${DB_COM} -h${DB_H} -u${DB_USER} -p${DB_PASS} ${DB} -e "select count(*) from  ${DB_S} where service_id='${KEY_ID}' and check_info='${CPU_CI}';"|awk 'NR>1')
if [[ ${CPU_LOAD_USE1} -gt ${CPU_Y} ]]; then
echo "${date2} CPU使用率${CPU_LOAD_USE}<br\>空闲率${CPU_LOAD_FREE}">>${LOG_DIR}/log.log
     if [[ ${CPU_C} -eq 0 ]] ; then
${DB_COM} -h${DB_H} -u${DB_USER} -p${DB_PASS} ${DB} -e "insert into ${DB_S} (${DB_S_FIELD}) values ('${CPU_CI}','1','使用率${CPU_LOAD_USE}<br/>空闲率${CPU_LOAD_FREE}',NOW(),'${KEY_ID}');"
  else
${DB_COM} -h${DB_H} -u${DB_USER} -p${DB_PASS} ${DB} -e "update ${DB_S} set status='1',remark='使用率${CPU_LOAD_USE}<br/>空闲率${CPU_LOAD_FREE}',report_time=NOW() where check_info='${CPU_CI}' and service_id='${KEY_ID}';"
  fi
else
${DB_COM} -h${DB_H} -u${DB_USER} -p${DB_PASS} ${DB} -e "delete from ${DB_S} where check_info='${CPU_CI}' and service_id='${KEY_ID}';"
fi

######内存使用情况######"
MEMTOTAL=`free -m|grep Mem|awk -F" " '{print $2}'`
MEMUSE=`free -m|grep Mem|awk -F" " '{print $3}'`
SWAPTOTAL=`free -m|grep Swap|awk -F" " '{print $2}'`
SWAPUSE=`free -m|grep Swap|awk -F" " '{print $3}'`
SWAPFREE=`free -m|grep Swap|awk -F" " '{print $4}'`
MEMU=`expr ${MEMUSE} \* 100 / ${MEMTOTAL}`"%"
SWAPU=`expr ${SWAPUSE} \* 100 / ${SWAPTOTAL}`"%"
MEM_SUM_NUM=$(free -m | grep "Mem:" | awk -F" " '{print $2}')
MEM_SURPLUS_NUM=$(free -m | grep "Mem:" | awk '{for(i=4;i<=NF;i++) print $i""FS;}' | awk '{a+=$1}END{print a}')
MEM_SUM=$(free -m | grep "Mem:" | awk -F" " '{print $2}')
MEM_SURPLUS=$(free -m | grep "Mem:" | awk '{for(i=4;i<=NF;i++) print $i""FS;}' | awk '{a+=$1}END{print a}')
MEM_USED=$(echo $(($MEM_SUM_NUM-$MEM_SURPLUS_NUM)))
PERCENT=$(printf "%d%%" $(($MEM_USED*100/$MEM_SUM_NUM)))
PERCENT_NUM=$(echo $PERCENT|sed s/%//g)
MEM_Y=$(${DB_COM} -h${DB_H} -u${DB_USER} -p${DB_PASS} ${DB} -e "select threshold_value from ${DB_Y} where status='0' and check_info='${MEM_CI}' limit 1;"|awk 'NR>1')
MEM_C=$(${DB_COM} -h${DB_H} -u${DB_USER} -p${DB_PASS} ${DB} -e "select count(*) from  ${DB_S} where service_id='${KEY_ID}' and check_info='${MEM_CI}';"|awk 'NR>1')
if [[ ${PERCENT_NUM} -gt ${MEM_Y} ]]; then
echo "${date2} 内存总大小：${MEM_SUM}<br/>已用：${MEM_USED}<br/>未用：${MEM_SURPLUS}<br/>使用率：${PERCENT}">>${LOG_DIR}/log.log
     if [[ ${MEM_C} -eq 0 ]] ; then
${DB_COM} -h${DB_H} -u${DB_USER} -p${DB_PASS} ${DB} -e "insert into ${DB_S} (${DB_S_FIELD}) values ('${MEM_CI}','1','总大小：${MEM_SUM}"M"<br/>已用：${MEM_USED}"M"\<br/\>未用：${MEM_SURPLUS}"M"<br/>使用率：${PERCENT}',NOW(),'${KEY_ID}');"
  else
${DB_COM} -h${DB_H} -u${DB_USER} -p${DB_PASS} ${DB} -e "update ${DB_S} set status='1',remark='总大小：${MEM_SUM}"M"<br/>已用：${MEM_USED}"M"<br/>未用：${MEM_SURPLUS}"M"<br/>使用率：${PERCENT}',report_time=NOW() where check_info='${MEM_CI}' and service_id='${KEY_ID}';"
  fi
else
${DB_COM} -h${DB_H} -u${DB_USER} -p${DB_PASS} ${DB} -e "delete from ${DB_S} where check_info='${MEM_CI}' and service_id='${KEY_ID}';"
fi

######磁盘使用量#############
IFS="
"
DISK_ERROR=$(
for i in `df -hP | sed 1d`
do 
 DISK_UTILIZ=$(echo $i |awk  '{print $5}')
 DISK_TOTAL=$(echo $i |awk  '{print $2}')
 DISK_USE=$(echo $i |awk  '{print $3}')
 DISK_FREE=$(echo $i |awk  '{print $4}')
 MOUNT_DISK=$(echo $i |awk  '{print $6}')
 if [[ $(echo $DISK_UTILIZ | sed s/%//g) -gt 0 ]]
   then
        echo -n "${MOUNT_DISK} ${DISK_TOTAL} ${DISK_USE} ${DISK_FREE} ${DISK_UTILIZ}<br/>"
 fi
done
)
DISK_Y=$(${DB_COM} -h${DB_H} -u${DB_USER} -p${DB_PASS} ${DB} -e "select threshold_value from ${DB_Y} where status='0' and check_info='${DISK_CI}' limit 1;"|awk 'NR>1')
DISK_C=$(${DB_COM} -h${DB_H} -u${DB_USER} -p${DB_PASS} ${DB} -e "select count(*) from  ${DB_S} where service_id='${KEY_ID}' and check_info='${DISK_CI}';"|awk 'NR>1')
if [[ -n "$DISK_ERROR" ]] ;then
echo "${date2} ${DISK_ERROR}">>${LOG_DIR}/log.log
     if [[ ${DISK_C} -eq 0 ]] ; then
${DB_COM} -h${DB_H} -u${DB_USER} -p${DB_PASS} ${DB} -e "insert into ${DB_S} (${DB_S_FIELD}) values ('${DISK_CI}','1','${DISK_ERROR}',NOW(),'${KEY_ID}');"
  else
${DB_COM} -h${DB_H} -u${DB_USER} -p${DB_PASS} ${DB} -e "update ${DB_S} set status='1',remark='${DISK_ERROR}',report_time=NOW() where check_info='${DISK_CI}' and service_id='${KEY_ID}';"
  fi
else
${DB_COM} -h${DB_H} -u${DB_USER} -p${DB_PASS} ${DB} -e "delete from ${DB_S} where check_info='${DISK_CI}' and service_id='${KEY_ID}';"
fi

######磁盘IO#############
DISKIO_Y=$(${DB_COM} -h${DB_H} -u${DB_USER} -p${DB_PASS} ${DB} -e "select threshold_value from ${DB_Y} where status='0' and check_info='${DISKIO_CI}' limit 1;"|awk 'NR>1')
DISKIO_C=$(${DB_COM} -h${DB_H} -u${DB_USER} -p${DB_PASS} ${DB} -e "select count(*) from  ${DB_S} where service_id='${KEY_ID}' and check_info='${DISKIO_CI}';"|awk 'NR>1')
IFS="
"
DISK_IO=$(
for i in `iostat -d|sed '1,3d'|sed '$d'`
do
DISK_M=$(echo -e $i|awk '{print $1}')
DISK_R=$(echo -e $i|awk '{print $3}')
DISK_W=$(echo -e $i|awk '{print $4}')
DISK_RZ=$(echo -e $i|awk '{print $3}'|awk -F"." '{print $1}')
DISK_WZ=$(echo -e $i|awk '{print $4}'|awk -F"." '{print $1}')
if [[ ${DISK_RZ} -gt ${DISKIO_Y} ]] || [[ ${DISK_WZ} -gt ${DISKIO_Y} ]]
then
echo -n "${DISK_M}的读取速率为：${DISK_R}<br/>${DISK_M}的写入速率为：${DISK_W}<br/>不正常<br/>"
fi
done
)
DISK_IO1=$(echo -e "$DISK_IO"|awk -F"<br/>" '{print $1"<br/>"$2"<br/>"$3}')
if [[ -n "$DISK_IO" ]] ;then
echo "${date2} ${DISK_IO1}">>${LOG_DIR}/log.log
     if [[ ${DISKIO_C} -eq 0 ]] ; then
${DB_COM} -h${DB_H} -u${DB_USER} -p${DB_PASS} ${DB} -e "insert into ${DB_S} (${DB_S_FIELD}) values ('${DISKIO_CI}','1','${DISK_IO1}',NOW(),'${KEY_ID}');"
     else
${DB_COM} -h${DB_H} -u${DB_USER} -p${DB_PASS} ${DB} -e "update ${DB_S} set status='1',remark='${DISK_IO1}',report_time=NOW() where check_info='${DISKIO_CI}' and service_id='${KEY_ID}';"
      fi
else
${DB_COM} -h${DB_H} -u${DB_USER} -p${DB_PASS} ${DB} -e "delete from ${DB_S} where check_info='${DISKIO_CI}' and service_id='${KEY_ID}';"
fi

######网络流量情况######"
NETI=$(sar -n DEV 1 1 |grep ${netcard}|grep Average|awk '{print $5}')
NETI1=$(sar -n DEV 1 1 |grep ${netcard}|grep Average|awk '{print $5}'|awk -F. '{print $1}')
NETO=$(sar -n DEV 1 1 |grep ${netcard}|grep Average|awk '{print $6}')
NETO1=$(sar -n DEV 1 1 |grep ${netcard}|grep Average|awk '{print $6}'|awk -F. '{print $1}')
NET_Y=$(${DB_COM} -h${DB_H} -u${DB_USER} -p${DB_PASS} ${DB} -e "select threshold_value from ${DB_Y} where status='0' and check_info='${NET_IO_CI}' limit 1;"|awk 'NR>1')
NET_C=$(${DB_COM} -h${DB_H} -u${DB_USER} -p${DB_PASS} ${DB} -e "select count(*) from  ${DB_S} where service_id='${KEY_ID}' and check_info='${NET_IO_CI}';"|awk 'NR>1')
if [[ ${NETI1} -gt ${NET_Y} || ${NETO1} -gt ${NET_Y} ]]; then
echo "${date2} 每秒钟接收${NETI}kB<br/>每秒钟发送${NETO}kB">>${LOG_DIR}/log.log
     if [[ ${NET_C} -eq 0 ]] ; then
${DB_COM} -h${DB_H} -u${DB_USER} -p${DB_PASS} ${DB} -e "insert into ${DB_S} (${DB_S_FIELD}) values ('${NET_IO_CI}','1','每秒钟接收${NETI}kB<br/>每秒钟发送${NETO}kB',NOW(),'${KEY_ID}');"
  else
${DB_COM} -h${DB_H} -u${DB_USER} -p${DB_PASS} ${DB} -e "update ${DB_S} set status='1',remark='每秒钟接收${NETI}kB<br/>每秒钟发送${NETO}kB',report_time=NOW() where check_info='${NET_IO_CI}' and service_id='${KEY_ID}';"
  fi
else
${DB_COM} -h${DB_H} -u${DB_USER} -p${DB_PASS} ${DB} -e "delete from ${DB_S} where check_info='${NET_IO_CI}' and service_id='${KEY_ID}';"
fi
}
######日志检测######"
log () {
LOG_TC=$(${DB_COM} -h${DB_H} -u${DB_USER} -p${DB_PASS} ${DB} -N -e "select count(*) from ${DB_LT} where service_id='${KEY_ID}' and status='0';")
LOG_LC=$(${DB_COM} -h${DB_H} -u${DB_USER} -p${DB_PASS} ${DB} -N -e "select count(*) from ${DB_LL} where service_id='${KEY_ID}' and status='0';")

if [[ ${LOG_TC} -ne 0 ]] ; then
${DB_COM} -h${DB_H} -u${DB_USER} -p${DB_PASS} ${DB} -e "delete from ${DB_LL};"

${DB_COM} -h${DB_H} -u${DB_USER} -p${DB_PASS} ${DB} -N -e "select list,log_name,warn_info from ${DB_LT} where service_id='${KEY_ID}' and status='0';"| while read LOG_D LOG_NAM LOG_K
do
LOGNAME=$(find ${LOG_D}/ -type f -mmin -1000 -name "*${LOG_NAM}*" |awk -F"/" '{print $NF}')
  if [[ -n "${LOGNAME}" ]] ; then
    for i in ${LOGNAME}
    do
${DB_COM} -h${DB_H} -u${DB_USER} -p${DB_PASS} ${DB} -e "insert into ${DB_LL} (${DB_LL_FIELD}) values ('${LOG_D}','${i}','${LOG_K}','0',NOW(),'${KEY_ID}','0','0');"
LOG_LFC=$(${DB_COM} -h${DB_H} -u${DB_USER} -p${DB_PASS} ${DB} -N -e "select count(*) from ${DB_LLF} where service_id='${KEY_ID}' and list='${LOG_D}' and log_name='${i}' and warn_info='${LOG_K}' and status='0';")
          if [[ ${LOG_LFC} -ne 0 ]] ; then
LOGNO=$(${DB_COM} -h${DB_H} -u${DB_USER} -p${DB_PASS} ${DB} -N -e "select log_line from ${DB_LLF} where service_id='${KEY_ID}' and list='${LOG_D}' and log_name='${i}' and warn_info='${LOG_K}' and status='0' group by  add_time  desc limit 1;")
ERRORNO=$(${DB_COM} -h${DB_H} -u${DB_USER} -p${DB_PASS} ${DB} -N -e "select err_line from ${DB_LLF} where service_id='${KEY_ID}' and list='${LOG_D}' and log_name='${i}' and warn_info='${LOG_K}' and status='0' group by  add_time  desc limit 1;")
${DB_COM} -h${DB_H} -u${DB_USER} -p${DB_PASS} ${DB} -e "update ${DB_LL} set err_line=${ERRORNO},log_line='${LOGNO}',add_time=NOW() where service_id='${KEY_ID}' and list='${LOG_D}' and log_name='${i}' and warn_info='${LOG_K}' and status='0';"
          fi
    done
  fi
done

LOG_LC=$(${DB_COM} -h${DB_H} -u${DB_USER} -p${DB_PASS} ${DB} -N -e "select count(*) from ${DB_LL} where service_id='${KEY_ID}' and status='0';")
    if [[ ${LOG_LC} -ne 0 ]] ; then
${DB_COM} -h${DB_H} -u${DB_USER} -p${DB_PASS} ${DB} -N -e "select list,log_name,warn_info,log_line from ${DB_LL} where service_id='${KEY_ID}' and status='0';"| while read LOG_D1 LOG_NAME LOG_KEY LOG_NO
do
LOG_NO1=$(tail -n +${LOG_NO} ${LOG_D1}/${LOG_NAME}|grep -nri "${LOG_KEY}"|tail -1|awk -F":" '{print $1}')
LOG_NO3=$(cat ${LOG_D1}/${LOG_NAME}|wc -l)
 #    if [ -n "${LOG_NO1}" ] && [ -n "${LOG_ME}" ] ;then
     if [[ -n "${LOG_NO1}" ]] ;then
#      if [[ "${LOG_NO1}0" -ne 0 ]] ;then
LOG_NO2=`expr $LOG_NO + $LOG_NO1`
LOG_T=$(tail -n +${LOG_NO} ${LOG_D1}/${LOG_NAME}|grep -rin "${LOG_KEY}"|tail -1|cut -c 11-30)
#LOG_ME=$(tail -n +${LOG_NO} ${LOG_D1}/${LOG_NAME}|grep -rin "${LOG_KEY}"|tail -1|awk '{$1="";$2="";sub(/^[ \t]+/,"");print $0}'|cut -c 1-100)
LOG_ME=$(tail -n +${LOG_NO} ${LOG_D1}/${LOG_NAME}|grep -ri "${LOG_KEY}"|tail -1|cut -c 1-100)
LOG_ME1=${LOG_ME//\'/ }
LOG_ME2=${LOG_ME1//\"/ }
${DB_COM} -h${DB_H} -u${DB_USER} -p${DB_PASS} ${DB} -e "insert into ${DB_LE} (${DB_LE_FIELD}) values ('${LOG_ME2}','${LOG_NAME}','${LOG_T}','${LOG_NO2}','1',NOW(),'${KEY_ID}');"
${DB_COM} -h${DB_H} -u${DB_USER} -p${DB_PASS} ${DB} -e "insert into ${DB_LLF} (${DB_LLF_FIELD}) values ('${LOG_D1}','${LOG_NAME}','${LOG_KEY}','0',NOW(),'${KEY_ID}','${LOG_NO3}','${LOG_NO2}');"
#${DB_COM} -h${DB_H} -u${DB_USER} -p${DB_PASS} ${DB} -e "update ${DB_LL} set log_line='${LOG_NO3}',err_line='${LOG_NO2}',add_time=NOW() where service_id='${KEY_ID}' and list='${LOG_D1}' and log_name='${LOG_NAME}' and warn_info='${LOG_KEY}' and status='0';"
echo "${date2} ${LOG_ME} ${LOG_D1} ${LOG_NAME} ${LOG_T} ${LOG_NO3} ${LOG_NO2} 0 ${KEY_ID}">>${LOG_DIR}/log.log
     else
#${DB_COM} -h${DB_H} -u${DB_USER} -p${DB_PASS} ${DB} -e "update ${DB_LLF} set log_line='${LOG_NO3}',add_time=NOW() where service_id='${KEY_ID}' and list='${LOG_D1}' and log_name='${LOG_NAME}' and warn_info='${LOG_KEY}' and status='0' group by  add_time  desc limit 1;"
${DB_COM} -h${DB_H} -u${DB_USER} -p${DB_PASS} ${DB} -e "insert into ${DB_LLF} (${DB_LLF_FIELD}) values ('${LOG_D1}','${LOG_NAME}','${LOG_KEY}','0',NOW(),'${KEY_ID}','${LOG_NO3}','${LOG_NO}');"
echo "${date2} 没有错误日志 ${LOG_D1} ${LOG_NAME} ${LOG_NO3} ${KEY_ID}">>${LOG_DIR}/log.log

      fi
done
    fi
else
echo "${date2} 需要检测的日志目录文件不存在">>${LOG_DIR}/log.log
fi
${DB_COM} -h${DB_H} -u${DB_USER} -p${DB_PASS} ${DB} -e "delete from  ${DB_LLF} where add_time<'${date3}';"
}
######MYSQL服务######"
mysql () {
  /etc/init.d/mysqld status 1>/dev/null 2>&1
  MYSQLD=$?
  /etc/init.d/mysql.server status 1>/dev/null 2>&1
  MYSQL_S=$?
  /etc/init.d/mysql status 1>/dev/null 2>&1
  MYSQL=$?
  MYSQLNET=`netstat -ntpl|grep ${DB_PORT}|wc -l`
  if [[ ${MYSQLD} -ne 0 && ${MYSQL_S} -ne 0 && ${MYSQL} -ne 0 || ${MYSQLNET} -eq 0 ]] ; then
echo "${date2} MYSQL进程不存在或端口没监听">>${LOG_DIR}/log.log
${DB_COM} -h${DB_H} -u${DB_USER} -p${DB_PASS} ${DB} -e "insert into ${DB_P} (${DB_P_FIELD}) values ('${MYSQL_CI}','1','MYSQL进程不存在或端口没监听',NOW(),'${KEY_ID}');"
  fi
}
######FTP服务######"
ftp () {
/etc/init.d/vsftpd status 1>/dev/null 2>&1
FTP=$?
FTPNET=`netstat -ntpl|grep 21|grep vsftp|wc -l`
  if [[ ${FTP} -ne 0 ]] || [[ ${FTPNET} -eq 0 ]] ; then
${DB_COM} -h${DB_H} -u${DB_USER} -p${DB_PASS} ${DB} -e "insert into ${DB_P} (${DB_P_FIELD}) values ('${FTP_CI}','1','ftp进程不存在或端口没监听',NOW(),'${KEY_ID}');"
echo "${date2} ftp进程不存在或端口没监听">>${LOG_DIR}/log.log
  fi
}

######NIFI服务######"
nifi () {
/opt/nifi-1.5.0/bin/nifi.sh status 1>/dev/null 2>&1
NIFI=$?
NIFINET=`netstat -ntpl|grep ${NIFI_PORT}|wc -l`
  if [[ ${NIFI} -ne 0 ]] || [[ ${NIFINET} -eq 0 ]] ; then
${DB_COM} -h${DB_H} -u${DB_USER} -p${DB_PASS} ${DB} -e "insert into ${DB_P} (${DB_P_FIELD}) values ('${NIFI_CI}','1','nifi进程不存在或端口没监听',NOW(),'${KEY_ID}');"
echo "${date2} nifi进程不存在或端口没监听">>${LOG_DIR}/log.log
  fi
}
######MFSMASTER服务######"
mfsmaster () {
  /etc/init.d/mfsmaster status 1>/dev/null 2>&1
  MFSMASTER=$?
  ps -ef | grep "mfsmaster" | grep -v grep 1>/dev/null 2>&1
  RESULT_MASTERPROC6=$?
  ps -ef | grep "mfsmetalogger" | grep -v grep 1>/dev/null 2>&1
  if [[ ${MFSMASTER} -ne 0 || ${RESULT_MASTERPROC6} -ne 0 ]] ; then
${DB_COM} -h${DB_H} -u${DB_USER} -p${DB_PASS} ${DB} -e "insert into ${DB_P} (${DB_P_FIELD}) values ('${MFSM_CI}','1','mfsmaster进程不存在',NOW(),'${KEY_ID}');"
echo "${date2} mfsmaster进程不存在或端口没监听">>${LOG_DIR}/log.log
  fi
}
######MFSMETALOGGER服务######"
mfsmetalogger () {
  /etc/init.d/mfsmetalogger status 1>/dev/null 2>&1
  MFSMETALOGGER=$?
  ps -ef | grep "mfsmetalogger" | grep -v grep 1>/dev/null 2>&1
  RESULT_METALOGGERPROC6=$?
  if [[ ${MFSMETALOGGER} -ne 0 || ${RESULT_METALOGGERPROC6} -ne 0 ]] ; then
echo "${date2} mfsmetalogger进程不存在或端口没监听">>${LOG_DIR}/log.log
${DB_COM} -h${DB_H} -u${DB_USER} -p${DB_PASS} ${DB} -e "insert into ${DB_P} (${DB_P_FIELD}) values ('${MFSL_CI}','1','mfsmetalogger进程不存在',NOW(),'${KEY_ID}');"
  fi
}
######MFSCGISERV服务######"
mfscgiserv () {
  /etc/init.d/mfscgiserv status 1>/dev/null 2>&1
  MFSCGISERV=$?
  ps -ef | grep "mfscgiserv" | grep -v grep 1>/dev/null 2>&1
  RESULT_CGISERVPROC6=$?
  MFSCGISERV_net6=`netstat -ntpl|grep ${MFSCGISERV_PORT}|wc -l`
  if [[ ${MFSCGISERV} -ne 0 || ${RESULT_CGISERVPROC6} -ne 0 || ${MFSCGISERV_net6} -eq 0 ]] ; then
echo "${date2} mfscgiserv进程不存在或端口没监听">>${LOG_DIR}/log.log
${DB_COM} -h${DB_H} -u${DB_USER} -p${DB_PASS} ${DB} -e "insert into ${DB_P} (${DB_P_FIELD}) values ('${MFSG_CI}','1','mfscgiserv进程不存在或端口没监听',NOW(),'${KEY_ID}');"
  fi
}
######MFSCHUNKSERVER服务######"
mfschunkserver () {
  /etc/init.d/mfschunkserver status 1>/dev/null 2>&1
  MFSCH=$?
  ps -ef | grep "mfschunkserver" | grep -v grep 1>/dev/null 2>&1
  RESULT_CHPROC6=$?
  if [[ ${MFSCH} -ne 0 || ${RESULT_CHPROC6} -eq 0 ]] ; then
echo "${date2} mfschunkserver进程不存在或端口没监听">>${LOG_DIR}/log.log
${DB_COM} -h${DB_H} -u${DB_USER} -p${DB_PASS} ${DB} -e "insert into ${DB_P} (${DB_P_FIELD}) values ('${MFSC_CI}','1','mfschunkserver进程不存在',NOW(),'${KEY_ID}');"
  fi
}
######MFS挂载######"
mfsclient () {
  ps -ef | grep "mfsmount" | grep -v grep 1>/dev/null 2>&1
  RESULT_MOUNTPROC6=$?
  if [[ ${RESULT_MOUNTPROC6} -ne 0 ]] ; then
echo "${date2} mfs挂载异常">>${LOG_DIR}/log.log
${DB_COM} -h${DB_H} -u${DB_USER} -p${DB_PASS} ${DB} -e "insert into ${DB_P} (${DB_P_FIELD}) values ('${MFST_CI}','1','mfs挂载异常',NOW(),'${KEY_ID}');"
  fi
}
######引擎检查######"
engine () {
cesic_PROC=`ps -ef |grep cesic|wc -l`
if [[ ${cesic_PROC} -eq 1 ]] ; then
echo "${date2} 引擎进程不存在">>${LOG_DIR}/log.log
${DB_COM} -h${DB_H} -u${DB_USER} -p${DB_PASS} ${DB} -e "insert into ${DB_P} (${DB_P_FIELD}) values ('${ENGINE_CI}','1','引擎进程不存在',NOW(),'${KEY_ID}');"
   elif [[ ${cesic_PROC} -gt 2 ]]
    then
echo "${date2} 引擎进程重复">>${LOG_DIR}/log.log
${DB_COM} -h${DB_H} -u${DB_USER} -p${DB_PASS} ${DB} -e "insert into ${DB_P} (${DB_P_FIELD}) values ('${ENGINE_CI}','1','引擎进程重复',NOW(),'${KEY_ID}');"
fi
#EP=$(
#sh `dirname $0`/indexch.sh
#)
#if [ -n "$EP" ] ;then
#${DB_COM} -h${DB_H} -u${DB_USER} -p${DB_PASS} ${DB} -e "insert into ${DB_P} (${DB_P_FIELD}) values ('${ENGINE_CI}','1','${EP}',NOW(),'${KEY_ID}');"
#fi
}
######质检服务######"
quality () {
quality_W_PROC=$(ps -ef | grep "wildfly" | grep ${quality_wildfly_dir}|wc -l)
quality_T_PROC=$(ps -ef | grep "tomcat" | grep ${quality_tomcat_dir}|wc -l)
quality_net=$(netstat -ntpl | grep ${quality_port} | wc -l)
if [[ ${quality_T_PROC} -le 2 && ${quality_net} -le 1 ]] || [[ ${quality_W_PROC} -le 2 && ${quality_net} -le 1 ]]
 then
echo "${date2} 质检进程不存在或端口未监听">>${LOG_DIR}/log.log
${DB_COM} -h${DB_H} -u${DB_USER} -p${DB_PASS} ${DB} -e "insert into ${DB_P} (${DB_P_FIELD}) values ('${QUALITY_CI}','1','质检进程不存在或端口未监听',NOW(),'${KEY_ID}');"
fi
}
######归集服务######"
cesic () {
T_PROC=$(ps -ef | grep "cesic" | grep ${cesic_T_dir}|wc -l)
W_PROC=$(ps -ef | grep "cesic" | grep ${cesic_W_dir}|wc -l)
if [[ ${T_PROC} -le 1 ]] && [[ ${W_PROC} -lt 2 ]]
 then
echo "${date2} 归集进程不存在">>${LOG_DIR}/log.log
${DB_COM} -h${DB_H} -u${DB_USER} -p${DB_PASS} ${DB} -e "insert into ${DB_P} (${DB_P_FIELD}) values ('${CESIC_CI}','1','归集进程不存在',NOW(),'${KEY_ID}');"
fi
}
######REDIS服务######"
redis () {
redis_PROC=$(ps -ef | grep "redis" | wc -l)
redis_net=$(netstat -ntl | grep ${redis_port} | wc -l)
${redis_cli} -h ${IP} -p ${redis_port} ping 1>/dev/null 2>&1
redis_inter=$?
if [[ ${redis_PROC} -le 1 || ${redis_net} -le 0 ]] || [[ ${redis_inter} -ne 0 ]]
 then
echo "${date2} REDIS进程不存在或端口未监听">>${LOG_DIR}/log.log
${DB_COM} -h${DB_H} -u${DB_USER} -p${DB_PASS} ${DB} -e "insert into ${DB_P} (${DB_P_FIELD}) values ('${REDIS_CI}','1','REDIS进程不存在或端口未监听',NOW(),'${KEY_ID}');"
fi
}
######CDH_NN服务######"
cdh_PROC=`ps -ef | grep cloudera|wc -l`
cdh_net=$(netstat -ntpl | grep ${CDH_PORT} | wc -l)
cdh_nn () {
if [[ ${cdh_PROC} -le 1 || ${cdh_net} -le 1 ]]
 then
echo "${date2} CDH_NN进程不存在或端口未监听">>${LOG_DIR}/log.log
${DB_COM} -h${DB_H} -u${DB_USER} -p${DB_PASS} ${DB} -e "insert into ${DB_P} (${DB_P_FIELD}) values ('${CDH_NN_CI}','1','CDH_NN进程不存在或端口未监听',NOW(),'${KEY_ID}');"
fi
}
######CDH_DN服务######"
cdh_dn () {
if [[ ${cdh_PROC} -le 1 ]]
 then
echo "${date2} CDH_DN进程不存在">>${LOG_DIR}/log.log
${DB_COM} -h${DB_H} -u${DB_USER} -p${DB_PASS} ${DB} -e "insert into ${DB_P} (${DB_P_FIELD}) values ('${CDH_DN_CI}','1','CDH_DN进程不存在',NOW(),'${KEY_ID}');"
fi
}
######SOLR服务######"
solr () {
solr_PROC=$(ps -ef | grep "$solr_dir" |wc -l)
solr_net=$(netstat -ntpl | grep ${solr_port} | wc -l)
if [[ ${solr_PROC} -le 1 || ${solr_net} -le 0 ]] ; then
echo "${date2} solr进程不存在">>${LOG_DIR}/log.log
${DB_COM} -h${DB_H} -u${DB_USER} -p${DB_PASS} ${DB} -e "insert into ${DB_P} (${DB_P_FIELD}) values ('${SOLR_CI}','1','solr进程不存在',NOW(),'${KEY_ID}');"
   elif [[ ${solr_PROC} -gt 2 || ${solr_net} -gt 1 ]]
    then
echo "${date2} solr进程重复">>${LOG_DIR}/log.log
${DB_COM} -h${DB_H} -u${DB_USER} -p${DB_PASS} ${DB} -e "insert into ${DB_P} (${DB_P_FIELD}) values ('${SOLR_CI}','1','solr进程重复',NOW(),'${KEY_ID}');"
fi
}
######运维平台服务######"
smartv () {
smartv_PROC=$(ps -ef | grep "httpd" |wc -l)
smartv_net=$(netstat -ntpl | grep ${smartv_port} | wc -l)
if [[ ${smartv_PROC} -le 1 || ${smartv_net} -le 0 ]]
 then
echo "${date2} 运维平台服务进程不存在">>${LOG_DIR}/log.log
${DB_COM} -h${DB_H} -u${DB_USER} -p${DB_PASS} ${DB} -e "insert into ${DB_P} (${DB_P_FIELD}) values ('${SMARTV_CI}','1','运维平台服务进程不存在',NOW(),'${KEY_ID}');"
fi
}
solr_interface () {
SOLR_J1=`${SOLR_SH} healthcheck -c collection1 -z ${SOLR_IP}:${SOLR_PORT}|jq -r '.shards[].replicas[].status'`
SOLR_J1_1=`${SOLR_SH} healthcheck -c collection1 -z ${SOLR_IP}:${SOLR_PORT}|jq -r '.shards[].status'`
SOLR_J2=`${SOLR_SH} healthcheck -c collection2 -z ${SOLR_IP}:${SOLR_PORT}|jq -r '.shards[].replicas[].status'`
SOLR_J3=`${SOLR_SH} healthcheck -c collection3 -z ${SOLR_IP}:${SOLR_PORT}|jq -r '.shards[].replicas[].status'`
if [[ ! -n ${SOLR_J1} ]] || [[ ! -n ${SOLR_J2} ]] || [[ ! -n ${SOLR_J3} ]];then
${DB_COM} -h${DB_H} -u${DB_USER} -p${DB_PASS} ${DB} -e "insert into ${DB_P} (${DB_P_FIELD}) values ('${SOLR_IF_CI}','1','solr接口异常',NOW(),'${KEY_ID}');"
elif [[ ${SOLR_J1} =~ "BAD" ]] || [[ ${SOLR_J2} =~ "BAD" ]] || [[ ${SOLR_J3} =~ "BAD" ]];then
echo "${date2} solr接口异常">>${LOG_DIR}/log.log
${DB_COM} -h${DB_H} -u${DB_USER} -p${DB_PASS} ${DB} -e "insert into ${DB_P} (${DB_P_FIELD}) values ('${SOLR_IF_CI}','1','solr接口异常',NOW(),'${KEY_ID}');"
fi
}
cdh_interface () {
#CDH_JV5=`curl -u${USER}:${PASS} http://${CDH_V5_IP}:${CDH_PORT}/api/v5/clusters/Cluster%201%20-%20CDH4/services|jq -r '.items[].healthSummary'`
CDH_JV11=`curl -u${USER}:${PASS} http://${CDH_V_IP}:${CDH_PORT}/api/${V}/services|jq -r '.items[].healthSummary'`
if [[ ! -n ${cdh_interface} ]] || [[ ${CDH_JV11} =~ "BAD" ]];then
echo "${date2} CDH接口异常">>${LOG_DIR}/log.log
${DB_COM} -h${DB_H} -u${DB_USER} -p${DB_PASS} ${DB} -e "insert into ${DB_P} (${DB_P_FIELD}) values ('${CDH_IF_CI}','1','CDH接口异常',NOW(),'${KEY_ID}');"
fi
}
###${dateold}的转译情况###"
redio () {
num1=`ls ${downloads}/*/*/*.wav |wc -l`
num2=`ls ${results}/voiceresult/*.txt |wc -l`
if [[ ${num1} -gt ${num2} ]] ; then
echo "${date2} ${dateold}的转译情况','1','"语音量："${num1} "转译文本量："${num2}">>${LOG_DIR}/log.log
${DB_COM} -h${DB_H} -u${DB_USER} -p${DB_PASS} ${DB} -e "insert into ${DB_P} (${DB_P_FIELD}) values ('${REDIO_CI}','1','${dateold}的转译情况','1','"语音量："${num1} "转译文本量："${num2}',NOW(),'${KEY_ID}');"
fi
}

case "$1" in
  sys_list)
    sys_list
    ;;
  PING)
    PING
    ;;
  firewall)
    firewall
    ;;
  sys)
    sys
    ;;
  log)
    log
    ;;
  mysql)
    mysql
    ;;
  ftp)
    ftp
    ;;
  nifi)
    nifi
    ;;
  mfsmaster)
    mfsmaster
    ;;
  mfsmetalogger)
    mfsmetalogger
    ;;
  mfscgiserv)
    mfscgiserv
    ;;
  mfschunkserver)
    mfschunkserver
    ;;
  mfsclient)
    mfsclient
    ;;
  engine)
    engine
    ;;
  quality)
    quality
    ;;
  cesic)
  cesic
    ;;
  redis)
  redis
    ;;
  cdh_nn)
    cdh_nn
    ;;
  cdh_dn)
    cdh_dn
    ;;
  solr)
  solr
    ;;
  smartv)
  smartv
    ;;
  solr_interface)
  solr_interface
    ;;
  cdh_interface)
  cdh_interface
    ;;
  redio)
  redio
    ;;
  *)
    echo $"Usage: $0 {sys_list|PING|firewall|sys|log|mysql|ftp|nifi|mfsmaster|mfsmetalogger|mfscgiserv|mfschunkserver|mfsclient|engine|quality|cesic|redis|cdh_nn|cdh_dn|solr|smartv|solr_interface|cdh_interface|redio}"
    RETVAL=1
esac

exit

