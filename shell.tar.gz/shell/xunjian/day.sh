#!/bin/bash
PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
export PATH
source /etc/profile
date=`date +"%Y%m%d"`
LOG=`dirname $0`/log/log.log
mv $LOG `dirname $0`/log/log_${date}.log
#/bin/sh `dirname $0`/syschk.sh redio
