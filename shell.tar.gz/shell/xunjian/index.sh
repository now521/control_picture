#!/bin/bash
PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
export PATH
source /etc/profile
REDIS_H=127.0.0.1
REDIS_P=6379
#REDIS_C=/usr/local/bin/redis-cli
REDIS_C=/usr/local/redis/bin/redis-cli
KEY=NAME
date=`date +"%Y%m%d"`
date1=`date +"%Y%m%d%H%M%S"`
date2=`date +"%Y-%m-%d %H:%M:%S"`
dateold=`date -d '-1 day' +%Y%m%d`
DPM=$1
if [ -z $DPM ]
then
echo "USE |$0 poc"
exit
fi
${REDIS_C} -h ${REDIS_H} -p ${REDIS_P} HGETALL EXEC_DAY|sed -n '{N;s/\n/\t/p}'|sed -e '/done/d'|awk -F" " '{print $1}'|while read DAY
do
dir=/data/ftpdir/${DPM}/${DAY}
INDEX=$(find ${dir} -type f -name "*index"|awk -F\/ '{print $NF}')
for i in ${INDEX};do
LINE=$(awk -F\' '{print $10}' ${dir}/${i}|awk '{sum+=$1} END {print sum}')
${REDIS_C} -h ${REDIS_H} -p ${REDIS_P} HSET  ${KEY} "${i}" "${LINE}"
done
done
