#!/bin/bash
PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
export PATH
source /etc/profile
ini=`dirname $0`/config/sys.ini
for i in `awk 'NR == 1 {next} {print $1}' $ini`
do
sh `dirname $0`/syschk.sh $i
done
